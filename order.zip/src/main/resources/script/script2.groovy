import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

    // CSRF token
    def csrf = message.getHeaders().get("x-csrf-token")
    message.setProperty("CSRF_TOKEN", csrf)

    // Cookies (VERY IMPORTANT)
    def setCookies = message.getHeaders().get("set-cookie")
    if (setCookies != null) {
        def cookies = []
        setCookies.each { c ->
            cookies.add(c.split(";")[0])   // keep name=value only
        }
        message.setProperty("COOKIE", cookies.join("; "))
    }

    return message
}