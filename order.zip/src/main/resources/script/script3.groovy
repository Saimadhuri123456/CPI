import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

Message processData(Message message) {

    def payload = message.getBody(String)
    def xml = new XmlSlurper().parseText(payload)

    // Define boundaries
    def batchBoundary = "batch_001"
    def changeSetBoundary = "changeset_01"

    StringBuilder batchBody = new StringBuilder()

    // Batch header
    batchBody.append("--${batchBoundary}\r\n")
    batchBody.append("Content-Type: multipart/mixed; boundary=${changeSetBoundary}\r\n\r\n")

    // Loop through orders
    xml.A_ProductionOrder_2Type.each { order ->
        def orderNo = order.ManufacturingOrder.text()

        batchBody.append("--${changeSetBoundary}\r\n")
        batchBody.append("Content-Type: application/http\r\n")
        batchBody.append("Content-Transfer-Encoding: binary\r\n\r\n")

        batchBody.append("POST ReleaseOrder?ManufacturingOrder='${orderNo}' HTTP/1.1\r\n")
        batchBody.append("Content-Type: application/json\r\n\r\n")
        batchBody.append("{}\r\n")
    }

    // Close boundaries
    batchBody.append("--${changeSetBoundary}--\r\n")
    batchBody.append("--${batchBoundary}--")

    // Set payload
    message.setBody(batchBody.toString())

    // Set mandatory header
    message.setHeader("Content-Type", "multipart/mixed; boundary=${batchBoundary}")

    return message
}
