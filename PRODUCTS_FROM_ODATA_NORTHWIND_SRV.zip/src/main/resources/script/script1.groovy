import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    // 1. Fetch the Message Log Framework
    def messageLog = messageLogFactory.getMessageLog(message);
    
    if (messageLog != null) {
        // 2. Read headers from the current message context
        def map = message.getHeaders();
        
        def contentType = map.get("Content-Type");
        def trackingSource = map.get("Custom-Tracking-Source");
        
        // 3. Write them into the SAP CPI Searchable Log (MPL Custom Header Properties)
        if (contentType != null) {
            messageLog.addCustomHeaderProperty("Log-Content-Type", contentType.toString());
        }
        if (trackingSource != null) {
            messageLog.addCustomHeaderProperty("Log-Integration-Source", trackingSource.toString());
        }
        
        // Optional: Log a quick text attachment for easy debugging in Monitor view
        messageLog.addAttachmentAsString("Header_Logging_Status", "Custom headers successfully written to MPL properties.", "text/plain");
    }
    
    return message;
}
